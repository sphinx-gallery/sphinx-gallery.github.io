"""
A trivial local module to provide a value for plot_exp.py.
"""

N = 100
