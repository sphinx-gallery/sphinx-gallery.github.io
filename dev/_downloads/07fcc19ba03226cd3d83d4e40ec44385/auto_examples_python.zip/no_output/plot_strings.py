# -*- coding: utf-8 -*-
"""
Constrained Text output frame
=============================

This example captures the standard output and includes it in the
example. If output is too long it becomes automatically
framed into a text area.
"""

# Code source: Óscar Nájera
# License: BSD 3 clause

print('This is a long test Output\n' * 50)

####################################
# One line out

print('one line out')
